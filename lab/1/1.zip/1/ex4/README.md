## Exercise 4
The goal of the fourth exercise was to turn  change the amount of resistance of the potentiometer and change the delay time between the cycles of the led.


A photo of my assemblage is joined in the folder.

## Code

int sensorPin = A0;
int ledPin = 13;
int sensorValue = 0;

void setup() {
  pinMode(ledPin, OUTPUT);
}

void loop() {
  sensorValue = analogRead(sensorPin);
  digitalWrite(ledPin, HIGH);
  delay(sensorValue);
  digitalWrite(ledPin, LOW);
  delay(sensorValue);
}
  

## Issues
I did not get particular issues for this exercise.