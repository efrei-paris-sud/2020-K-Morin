Exercise 1 
Int he first exercise, I had to light the led.

There is a picture of my assemblage, but the led is willingly turned off, because otherwise we could not see anything because of the light.

## Code
No code was necessary for this ecercise

I did not get issues for this exercise.