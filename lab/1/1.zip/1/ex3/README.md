## Exercise 3
The goal of the third exercise was to turn on the built-in LED on pin 13 when i pressed a button.


A gif of my assemblage is joined in the folder.

## Code

const int buttonPin = 2;
const int ledPin = 13;

int buttonState = 0;

void setup() {
  pinMode(ledPin, OUTPUT);
  pinMode(buttonPin, INPUT);

}

void loop() {
  buttonState = digitalRead(buttonPin);

  if (buttonState == HIGH) {
    digitalWrite(ledPin, HIGH);
  } else {
    digitalWrite(ledPin, LOW);
  }
}
  

## Issues
The issues I had with this exercise were that the montage was doing the opposite of what i wanted, and that was because i connected it to vcc instead of gnd.