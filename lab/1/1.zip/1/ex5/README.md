## Exercise 5
The goal of the fifth exercise was to make the led blink but also fading.


A gif of my assemblage is joined in the folder.

## Code

int ledPin = 5;

void setup() {

}

void loop() {

  for (int fadeValue = 0 ; fadeValue <= 255; fadeValue += 5) {
    analogWrite(ledPin, fadeValue);
    delay(30);
  }

  for (int fadeValue = 255 ; fadeValue >= 0; fadeValue -= 5) {
    analogWrite(ledPin, fadeValue);
    delay(30);

  }
}
  

## Issues
I did not get particular issues for this exercise.