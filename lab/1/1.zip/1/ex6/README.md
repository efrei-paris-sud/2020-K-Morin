## Exercise 6
The goal of the sixth exercise was to make the passive buzzer buzz.


Unfortunately I forgot to take a picture of my montage, but I can put the image that I copied for my montage.

## Code

const int buzzer = 5;


void setup(){
  pinMode(buzzer, OUTPUT);
}

void loop(){
 
  tone(buzzer, 1000);
  delay(2000);
  noTone(buzzer);
  delay(2000);
  
}
  

## Issues
I did not get particular issues for this exercise.